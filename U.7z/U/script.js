let searchInput = document.getElementById("search-input");
let sortSelect = document.getElementById("sort-select");
let addItemButton = document.getElementById("add-item");
let itemList = document.getElementById("item-list");
let noResults = document.getElementById("no-results");
let items = JSON.parse(localStorage.getItem("items")) || [];
function renderList() {
    itemList.innerHTML = ""; 
    if (items.length === 0) {
        noResults.style.display = "block";
    } else {
        noResults.style.display = "none";
    }
    items.forEach(function (item) {
        let li = document.createElement("li");
        li.textContent = item.text; 
        itemList.appendChild(li);
    });
    localStorage.setItem("items", JSON.stringify(items));
}
searchInput.addEventListener("input", function () {
    let query = searchInput.value.toLowerCase(); 
    let filteredItems = items.filter(function (item) {
        return item.text.toLowerCase().includes(query); 
    });
    itemList.innerHTML = ""; 
    if (filteredItems.length === 0) {
        noResults.style.display = "block"; 
    } else {
        noResults.style.display = "none";
    }

    filteredItems.forEach(function (item) {
        let li = document.createElement("li");
        li.textContent = item.text;
        itemList.appendChild(li);
    });
});
sortSelect.addEventListener("change", function () {
    if (sortSelect.value === "alphabet") {
        items.sort(function (a, b) {
            return a.text.localeCompare(b.text);
        });
    } else if (sortSelect.value === "date") {
        items.sort(function (a, b) {
            return a.timestamp - b.timestamp; 
        });
    }
    renderList(); 
});
addItemButton.addEventListener("click", function () {
    let newItem = prompt("Введіть назву нового елемента:");
    if (newItem) {
        items.push({ text: newItem, timestamp: Date.now() }); 
        renderList();
    }
});
renderList();