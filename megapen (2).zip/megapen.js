// Завдання 1
let userAge = prompt("Скільки вам років?");
if (userAge === null || userAge === "") {
    alert("Ви нічого не ввели!");
} else {
    userAge = Number(userAge);
    if (userAge < 18) {
        alert("Вам заборонено вхід");
    } else if (userAge >= 18 && userAge <= 65) {
        alert("Ласкаво просимо!");
    } else if (userAge > 65) {
        alert("Будь ласка, будьте обережні!");
    } else {
        alert("Щось пішло не так. Спробуйте ще раз!");
    }
}

//Завдання 2
let n1 = prompt("Введіть число:");
n = Number(n);

for (let i = 2; i <= n; i += 2) {
    console.log(i);
}

//Завдання 3
let n = prompt("Введіть число:");
n = Number(n);
let factorial = 1;
let i = 1;
while (i <= n) {
    factorial *= i;
    i++;
}
console.log("Факторіал числа " + n + " дорівнює " + factorial);

//Завдання 4
let a = prompt("Введіть перше число:");
let b = prompt("Введіть друге число:");
let operation = prompt("Введіть операцію (+, -, *, /):");
a = Number(a);
b = Number(b);
let result;
switch (operation) {
    case "+":
        result = a + b;
        break;
    case "-":
        result = a - b;
        break;
    case "*":
        result = a * b;
        break;
    case "/":
        if (b !== 0) {
            result = a / b;
        } else {
            result = "Ділення на нуль неможливе!";
        }
        break;
    default:
        result = "Невірна операція!";
}
alert("Результат: " + result);

//Завдання 5
let secretNumber = Math.floor(Math.random() * 100) + 1;
let guess;
do {
    guess = prompt("Вгадайте число від 1 до 100:");
    guess = Number(guess);
    if (guess < secretNumber) {
        alert("Загадане число більше");
    } else if (guess > secretNumber) {
        alert("Загадане число менше");
    } else {
        alert("Вітаємо! Ви вгадали число!");
    }
} while (guess !== secretNumber);

